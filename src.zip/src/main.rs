mod decode;
mod vesseldata;

use std::env;
use std::error::Error;
use std::fs::File;
use std::io::{BufRead, BufReader};

use nmea_parser::{NmeaParser};

use vesseldata::VesselData;

fn main() -> Result<(), Box<dyn Error>> {

    let args: Vec<String> = env::args().collect();
    let ais_filepath = &args[1];

    decode::decode_to_csv(ais_filepath)?;

    Ok(())
}

fn display_vesseldata(vesseldata: &VesselData) {

    println!("{:#?}\n", vesseldata);
}