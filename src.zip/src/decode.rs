use nmea_parser::{NmeaParser, ParsedMessage, ParseError};

use crate::vesseldata::VesselData;

pub fn decode_to_csv(ais_filepath: &str) -> Result<(), Box<dyn Error>> {

    let mut parser = NmeaParser::new();

    let file = File::open(ais_filepath)?;
    let reader = BufReader::new(file);

    for line in reader.lines() {
        match line {

            Ok(text) => match decode_tagged_nmea(&mut parser, &text) {

                Ok(Some(vesseldata)) => {
                    display_vesseldata(&vesseldata);
                },

                Ok(None) => {},

                Err(e) => {
                    println!("Error parsing sentence: {}", e);
                }
            }

            Err(e) => {
                println!("Error reading line: {}", e);
            }
        }
    }

    Ok(())
}

pub fn decode_tagged_nmea(parser: &mut NmeaParser, tagged_sentence: &str) -> Result<Option<VesselData>, String> {

    let (sentence, source, timestamp): (Option<String>, Option<String>, Option<i32>) = parse_tags(tagged_sentence)?;
    let mut payload: Option<ParsedMessage> = None;

    if let Some(s) = sentence {
        match decode_nmea(parser, &s) {

            Ok(Some(parsed_message)) => {
                payload = Some(parsed_message);
            },

            Ok(None) => {
                return Ok(None);
            },

            Err(_) => {
                return Err("`nmea_parser::NmeaParser` could not decode the NMEA sentence".to_string())
            }
        }
    }

    Ok(Some(VesselData {
        payload: payload,
        source: source,
        timestamp: timestamp
    }))
}

pub fn parse_tags(tagged_sentence: &str) -> Result<(Option<String>, Option<String>, Option<i32>), String> {

    let tagged = tagged_sentence;
    let unquoted: &str;

    if tagged.starts_with('"') && tagged.ends_with('"') {
        unquoted = &tagged[1 .. tagged.len()-1];
    } else {
        unquoted = tagged;
    }

    let mut sentence: Option<String> = None;
    let mut source: Option<String> = None;
    let mut timestamp: Option<i32> = None;

    if let Some(payload_start) = unquoted.match_indices("!AIVDM").map(|(i, _)| i).next() {
        sentence = Some(unquoted[payload_start..].to_string());
    }

    let backslashes: Vec<_> = unquoted.match_indices('\\')
                                      .map(|(i, _)| i)
                                      .collect();

    if backslashes.len() >= 2 {

        let start = backslashes[0] + 1;
        let end = backslashes[1];
        let tag_block: &str = &unquoted[start..end];

        for tag_with_checksum in tag_block.split(',').rev() {

            let tag: &str;

            if tag_with_checksum.contains('*') {
                tag = tag_with_checksum.split('*').next().expect("`.next()` is called on this iterator only once");
            } else {
                tag = tag_with_checksum;
            }

            if tag.starts_with("c:") {
                if let Ok(epoch) = tag[2..].parse::<i32>() {
                    timestamp = Some(epoch);
                }

            } else if tag.starts_with("s:") {
                source = Some(tag[2..].to_string())
            }
        }
    }

    if sentence == None && source == None && timestamp == None {
        return Err("No tags or NMEA sentence found".to_string());
    }

    Ok((sentence, source, timestamp))
}

pub fn decode_nmea(parser: &mut NmeaParser, sentence: &str) -> Result<Option<ParsedMessage>, ParseError> {

    match parser.parse_sentence(sentence) {
        Ok(parsed_message) => match parsed_message {

            ParsedMessage::VesselStaticData(_) => {
                return Ok(Some(parsed_message));
            },

            ParsedMessage::VesselDynamicData(_) => {
                return Ok(Some(parsed_message));
            },

            ParsedMessage::Incomplete => {
                return Ok(None);
            },

            _ => {
                return Ok(None);
            }
        },

        Err(e) => {
            return Err(e);
        }
    }
}