use nmea_parser::{ParsedMessage};
use csv::Writer;

#[derive(Debug)]
pub struct VesselData {

	pub payload: Option<ParsedMessage>,
	pub source: Option<String>,
	pub timestamp: Option<i32>
}