# Bit-Array Iteration

This structure wraps a bit-array and provides by-value iteration of the bits it
contains.

## Original

[`array::IntoIter`](core::array::IntoIter)
