# Bit-Array Iteration

This module defines the core iteration logic for `BitArray`. It includes the
`IntoIterator` implementations on bit-arrays and their references, as well as
the `IntoIter` struct that walks bit-arrays by value.
