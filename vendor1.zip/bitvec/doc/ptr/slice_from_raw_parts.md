# Raw Bit-Slice Pointer Construction

This is an alias for [`bitslice_from_raw_parts`][0], renamed for symbol
compatibility. See its documentation instead.

## Original

[`ptr::slice_from_raw_parts`](core::ptr::slice_from_raw_parts)

[0]: crate::ptr::bitslice_from_raw_parts
