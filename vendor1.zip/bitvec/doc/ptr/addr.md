# Address Value Management

This module provides utilities for working with `T: BitStore` addresses so that
the other `ptr` submodules can rely on the correctness of their values when
doing pointer encoding.
