# Bit-wise `memset`

This is an alias for [`write_bits`][0], renamed for symbol compatibility. See
its documentation instead.

## Original

[`ptr::write_bytes`](core::ptr::write_bytes)

[0]: crate::ptr::write_bits
