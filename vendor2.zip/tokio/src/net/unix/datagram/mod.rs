//! Unix datagram types.

pub(crate) mod socket;
