// use std::io;

use nmea_parser::{
    NmeaParser, ParsedMessage,
};

pub fn nmea(parser: &mut NmeaParser, sentence: &str) {

    match parser.parse_sentence(sentence) {

        Ok(ParsedMessage::VesselDynamicData(parsed_message)) => {
            println!("Found dynamic data");
            println!("{:#?}\n", parsed_message);
        },

        Ok(ParsedMessage::VesselStaticData(parsed_message)) => {
            println!("Found static data");
            println!("{:#?}\n", parsed_message);
        },

        Ok(ParsedMessage::Incomplete) => {},

        Err(e) => {
            println!("Error: {}", e);
        },

        _ => {}
    }
}