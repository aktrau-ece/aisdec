use std::env;
use std::fs::File;
use std::io::{ self, BufRead, BufReader };

use nmea_parser::{
    NmeaParser
};

mod decode;

fn main() -> io::Result<()> {

    let args: Vec<String> = env::args().collect();
    let ais_filepath = &args[1];

    let mut parser = NmeaParser::new();

    let file = File::open(ais_filepath)?;
    let reader = BufReader::new(file);

    for line in reader.lines() {
        match line {

            Ok(line_content) => {

                decode::nmea(&mut parser, &line_content);

            }

            Err(e) => {
                println!("Error: {}", e);
            }
        }
    }

    Ok(())
}